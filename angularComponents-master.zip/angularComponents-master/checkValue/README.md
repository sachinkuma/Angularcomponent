# angularCheckValue
Checks if first input is greater than second.
